#include <string.h>
#include <stdio.h>
#include <math.h>

#include "Generic.h"
#include "cmd.h"

#include "hal_timer.h"
#include "hal_flash.h"

#include "default_config.h"

param_block_t defaultFConfig  = DEFAULT_CONFIG;


System_uart_dma_t sys_uart_dma_buf ={
	.uart_dma_tx = 0,
	.uart_dma_report = TRUE,
	.uart_dma_index = 0
};


//ȫ�ֽṹ��
System_Para_t sys_para = {
	.start_count = 0x0000,
	.param_Config = DEFAULT_CONFIG	
};



/*
 *	������ӡ�豸����
 *
 */
void App_Module_sys_para_debug(void)
{
	_dbg_printf("*******************UWB Module System Parameters*******************\r\n");
	_dbg_printf("   UWB Module Compiled Time %s %s\n",__TIME__,__DATE__);	

	_dbg_printf("   UWB Module SW Version��%s\r\n"  ,uwb_software_ver);
	_dbg_printf("   UWB Module HW Version��%s\r\n"  ,uwb_hardware_ver);

	_dbg_printf("   UWB Module Flag bit��%02X\r\n"    ,sys_para.flag);	
	_dbg_printf("   UWB Module Startup Count��%d\r\n"  ,sys_para.start_count);
	_dbg_printf("   UWB Module error_bit1:%d, error_bit2:%d, error_bit3:%d, error_bit:%d\r\n",
							sys_para.HardFault_error_bit,
							sys_para.MemManage_error_bit,
							sys_para.BusFault_error_bit,
							sys_para.UsageFault_error_bit);	

	_dbg_printf("\r\n");
	_dbg_printf("*******************UWB Module System Parameters*******************\r\n");
}


/*
 *	�豸ȫ�ֱ�����ʼ��
 *
 */
void App_Module_sys_para_Init(void)
{
	memset(&sys_para.flag, 0, sizeof(sys_para));
	
	sys_para.flag = 0xAAAA;
	sys_para.start_count = 0;

	sys_para.HardFault_error_bit	= 0;
	sys_para.MemManage_error_bit	= 0;
	sys_para.BusFault_error_bit		= 0;
	sys_para.UsageFault_error_bit	= 0;

	sys_para.param_Config = defaultFConfig;
}

  
/*
 *	Ӧ�ò� д�����ʧ������(���洢��)
 *
 */
void App_Module_Sys_Write_NVM(void)
{	
	//д�����洢��
	while(HalWrite_Flash(PAGE62_ADDR, &sys_para.flag, sizeof(sys_para)/4) == 0)
	{
		HalDelay_nMs(100);
	}
}


/*
 *	Ӧ�ò� ��ȡ����ʧ������
 *
 */
void App_Module_Sys_Read_NVM(void)
{
	HalRead_Flash(PAGE62_ADDR, &sys_para.flag, sizeof(sys_para)/4);     //�洢����ȡ
}

/*
 *	��ȡflash����������
 *
 */
void App_Module_sys_para_read()
{
    bool is_back2factory = false;

	App_Module_Sys_Read_NVM();
	
	
	if(sys_para.flag != 0xAAAA)
	{
		is_back2factory = true;     
		_dbg_printf("The device is powered on the first time\n");
	}
	else
	{
		sys_para.start_count +=1;     
		App_Module_Sys_Write_NVM();		
	}
	
    /*�ָ�����ģʽ*/
    if(is_back2factory == true)
    {
		App_Module_sys_para_Init();			
		App_Module_Sys_Write_NVM();			
		NVIC_SystemReset();      
    }
	
	load_bssConfig();                       //��ȡflash
}

/*
 *	Ӧ�ò� ʹ�ܲ���
 *
 */
void App_Module_Init(void)
{	
	HalDelay_nMs(500);

    //���ڶ���ʹ��
	App_Module_CMD_Queue_Init();

    //���ö�ȡ(flash)
	App_Module_sys_para_read();

    //���ô�ӡ
	App_Module_sys_para_debug();
}



/*
 *	Ӧ�ò� �¼�ģʽ
 *
 */
void App_Module_Sys_Work_Mode_Event()
{
	App_Module_Sys_Deal_UART_USB_CMD_Event(FALSE);		
}


/*
 *	Ӧ�ò� �����¼�
 *
 */
void App_Module_Sys_Deal_UART_USB_CMD_Event(bool flag)
{
	App_Module_Process_USB_CMD();		
	App_Module_Process_USART_CMD();
	if(flag == TRUE)				
		port_tx_msg("Please Send AT Command...\r\n", strlen("Please Send AT Command...\r\n")); 				

	//�����������������δ���ͣ�����
	if(sys_uart_dma_buf.uart_dma_index != 0)
	{
		port_tx_msg(NULL, 0);
	}
}

/*
 *	Ӧ�ò� LED�¼�
 *
 */
void App_Modelu_Sys_Deal_IO_LED_Event(uint16_t count)
{
	for(int i = 0; i < HAL_LED_ALL; i++)
	{
		if(hal_led[i].mode != HAL_LED_MODE_TOGGLE)
			continue;
		
		if( count % hal_led[i].period  == 0)
		{ 
			if((count / hal_led[i].period) % 2)
				HalLedSet (i, HAL_LED_MODE_ON);
			else
				HalLedSet (i, HAL_LED_MODE_OFF);
		} 		
	} 	
}

/*
 *	Ӧ�ò� LEDģʽ����
 *
 */
void App_Module_Sys_IO_Led_Mode_Set(Sys_Work_Mode Mode)
{
	static int val_mode = Sys_Operate_Mode_INVAILD;
	
	if(Mode == val_mode)
	{
		return;
	}
	else
	{	
		val_mode = Mode;
	}
	
	switch(Mode)
	{
		/*LED1*/
		case Sys_Operate_Mode_CFG_ING:	
				HalLed_Mode_Set(HAL_LED1, HAL_LED_MODE_TOGGLE, Sys_mode_led_blink_slow_time);		
			break;
				
		case Sys_Operate_Mode_WORK_DONE:		
				HalLed_Mode_Set(HAL_LED1, HAL_LED_MODE_TOGGLE, Sys_mode_led_blink_fast_time); 	
			break;
		default:
			break;
	}
}


==============================================================================
=                                                                            =
=                                                                            =
=                D E C A W A V E    C O N F I D E N T I A L                  =
=                                                                            =
=                                                                            =
==============================================================================

This software contains Decawave confidential information and techniques,
subject to licence and non-disclosure agreements.  No part of this software
package may be revealed to any third-party without the express permission of
Decawave Ltd.

==============================================================================

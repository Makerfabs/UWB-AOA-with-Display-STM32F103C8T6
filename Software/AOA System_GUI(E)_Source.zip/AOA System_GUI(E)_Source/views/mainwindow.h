// -------------------------------------------------------------------------------------------------------------------
//
//  File: MainWindow.h
//
//  Copyright 2015 (c) Decawave Ltd, Dublin, Ireland.
//
//  All rights reserved.
//
//  Author:
//
// -------------------------------------------------------------------------------------------------------------------

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QAbstractSocket>
#include <QLabel>
#include "serialconnection.h"
#include "serial_widget.h"

namespace Ui {
class MainWindow;
}

class SerialConnection;
class GraphicsWidget;
class ConnectionWidget;
class ViewSettingsWidget;
class serial_widget;
/**
 * The MainWindow class is the PDOA-RTLS application's Main Window widget.
 *
 * It is responsible for setting up all the dock widgets inside it, as weel as the central widget.
 * It also handles global shortcuts (Select All) and the Menu bar.
 */
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    GraphicsWidget *graphicsWidget();

    ViewSettingsWidget *viewSettingsWidget();

    /**
     * Create a new menu with the window's action
     * @see QMainWindow::createPopupMenu()
     * @return the new menu instance
     */
    virtual QMenu *createPopupMenu();

    /**
     * createPopupMenu adds the windows actions to \a menu.
     * The are the actions to hide or show dock widgets.
     * @param menu the QMenu instance to which the actions should be added
     * @return the menu object
     */
    QMenu *createPopupMenu(QMenu *menu);

    void saveConfigFile(QString filename, QString cfg);
    void loadConfigFile(QString filename);

    QString version();

public slots:
    void connectionStateChanged(SerialConnection::ConnectionState);
    void saveViewConfigSettings(void);

protected slots:
    void onReady();

    void loadSettings();
    void saveSettings();

    void onAboutAction();
    void onMiniMapView();

    void statusBarMessage(QString status);

private:
    Ui::MainWindow *const ui;
    QMenu *_helpMenu;
    QAction *_aboutAction;
    QLabel *_infoLabel;

    ConnectionWidget *_cWidget;

    bool _showMainToolBar;
    bool _notConnected;
};

#endif // MAINWINDOW_H
